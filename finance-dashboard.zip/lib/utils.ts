import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import type { Transaction, MonthlyData, CategoryData } from "@/lib/types"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function groupTransactionsByMonth(transactions: Transaction[]): MonthlyData[] {
  const monthlyData: Record<string, MonthlyData> = {}

  // Sort transactions by date
  const sortedTransactions = [...transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  // Group transactions by month
  sortedTransactions.forEach((transaction) => {
    const date = new Date(transaction.date)
    const monthYear = `${date.toLocaleString("default", { month: "short" })} ${date.getFullYear()}`

    if (!monthlyData[monthYear]) {
      monthlyData[monthYear] = {
        name: monthYear,
        income: 0,
        expenses: 0,
      }
    }

    if (transaction.type === "income") {
      monthlyData[monthYear].income += transaction.amount
    } else {
      monthlyData[monthYear].expenses += transaction.amount
    }
  })

  // Convert to array
  return Object.values(monthlyData)
}

export function groupTransactionsByCategory(transactions: Transaction[]): CategoryData[] {
  const categoryData: Record<string, number> = {}

  // Group transactions by category
  transactions.forEach((transaction) => {
    if (!categoryData[transaction.category]) {
      categoryData[transaction.category] = 0
    }

    categoryData[transaction.category] += transaction.amount
  })

  // Convert to array
  return Object.entries(categoryData).map(([name, value]) => ({
    name,
    value,
  }))
}
