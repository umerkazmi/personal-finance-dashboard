export type Category =
  | "Salary"
  | "Investments"
  | "Food"
  | "Rent"
  | "Utilities"
  | "Transportation"
  | "Entertainment"
  | "Shopping"
  | "Healthcare"
  | "Education"
  | "Travel"
  | "Other"

export type TransactionType = "income" | "expense"

export interface Transaction {
  id: string
  amount: number
  category: Category
  type: TransactionType
  date: string
  description?: string
}

export interface MonthlyData {
  name: string
  income: number
  expenses: number
}

export interface CategoryData {
  name: string
  value: number
}

export interface Currency {
  code: string
  symbol: string
  name: string
}
