import type { Transaction, Category, Currency } from "@/lib/types"

export const categories: Category[] = [
  "Salary",
  "Investments",
  "Food",
  "Rent",
  "Utilities",
  "Transportation",
  "Entertainment",
  "Shopping",
  "Healthcare",
  "Education",
  "Travel",
  "Other",
]

export const currencies: Currency[] = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
  { code: "CHF", symbol: "CHF", name: "Swiss Franc" },
  { code: "CNY", symbol: "¥", name: "Chinese Yuan" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "BRL", symbol: "R$", name: "Brazilian Real" },
]

// Generate sample data for the past 6 months
export const initialTransactions: Transaction[] = [
  // Current month
  {
    id: "1",
    amount: 3500,
    category: "Salary",
    type: "income",
    date: new Date(new Date().getFullYear(), new Date().getMonth(), 5).toISOString(),
    description: "Monthly salary",
  },
  {
    id: "2",
    amount: 1200,
    category: "Rent",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth(), 3).toISOString(),
    description: "Monthly rent",
  },
  {
    id: "3",
    amount: 350,
    category: "Food",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth(), 10).toISOString(),
    description: "Grocery shopping",
  },
  {
    id: "4",
    amount: 120,
    category: "Utilities",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth(), 15).toISOString(),
    description: "Electricity bill",
  },
  {
    id: "5",
    amount: 200,
    category: "Entertainment",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth(), 20).toISOString(),
    description: "Concert tickets",
  },

  // Previous month
  {
    id: "6",
    amount: 3500,
    category: "Salary",
    type: "income",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 1, 5).toISOString(),
    description: "Monthly salary",
  },
  {
    id: "7",
    amount: 1200,
    category: "Rent",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 1, 3).toISOString(),
    description: "Monthly rent",
  },
  {
    id: "8",
    amount: 300,
    category: "Food",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 1, 12).toISOString(),
    description: "Grocery shopping",
  },
  {
    id: "9",
    amount: 500,
    category: "Shopping",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 1, 18).toISOString(),
    description: "New clothes",
  },

  // 2 months ago
  {
    id: "10",
    amount: 3500,
    category: "Salary",
    type: "income",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 2, 5).toISOString(),
    description: "Monthly salary",
  },
  {
    id: "11",
    amount: 1200,
    category: "Rent",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 2, 3).toISOString(),
    description: "Monthly rent",
  },
  {
    id: "12",
    amount: 800,
    category: "Healthcare",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 2, 8).toISOString(),
    description: "Medical checkup",
  },

  // 3 months ago
  {
    id: "13",
    amount: 3500,
    category: "Salary",
    type: "income",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 3, 5).toISOString(),
    description: "Monthly salary",
  },
  {
    id: "14",
    amount: 1200,
    category: "Rent",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 3, 3).toISOString(),
    description: "Monthly rent",
  },
  {
    id: "15",
    amount: 1500,
    category: "Travel",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 3, 22).toISOString(),
    description: "Weekend trip",
  },

  // 4 months ago
  {
    id: "16",
    amount: 3500,
    category: "Salary",
    type: "income",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 4, 5).toISOString(),
    description: "Monthly salary",
  },
  {
    id: "17",
    amount: 1200,
    category: "Rent",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 4, 3).toISOString(),
    description: "Monthly rent",
  },
  {
    id: "18",
    amount: 400,
    category: "Education",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 4, 15).toISOString(),
    description: "Online course",
  },

  // 5 months ago
  {
    id: "19",
    amount: 3500,
    category: "Salary",
    type: "income",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 5, 5).toISOString(),
    description: "Monthly salary",
  },
  {
    id: "20",
    amount: 1200,
    category: "Rent",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 5, 3).toISOString(),
    description: "Monthly rent",
  },
  {
    id: "21",
    amount: 250,
    category: "Transportation",
    type: "expense",
    date: new Date(new Date().getFullYear(), new Date().getMonth() - 5, 10).toISOString(),
    description: "Car maintenance",
  },
]
