"use client"
import {
  Bar,
  BarChart as RechartsBarChart,
  Line,
  LineChart as RechartsLineChart,
  Pie,
  PieChart as RechartsPieChart,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

interface BarChartProps {
  data: any[]
  categories: string[]
  index: string
  colors: string[]
  valueFormatter?: (value: number) => string
  className?: string
}

export function BarChart({ data, categories, index, colors, valueFormatter, className }: BarChartProps) {
  return (
    <RechartsBarChart data={data} className={className}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey={index} />
      <YAxis tickFormatter={valueFormatter} />
      <Tooltip formatter={(value) => (valueFormatter ? [valueFormatter(value), ""] : [value, ""])} />
      <Legend />
      {categories.map((category, i) => (
        <Bar key={category} dataKey={category} fill={colors[i % colors.length]} />
      ))}
    </RechartsBarChart>
  )
}

interface LineChartProps {
  data: any[]
  categories: string[]
  index: string
  colors: string[]
  valueFormatter?: (value: number) => string
  className?: string
}

export function LineChart({ data, categories, index, colors, valueFormatter, className }: LineChartProps) {
  return (
    <RechartsLineChart data={data} className={className}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey={index} />
      <YAxis tickFormatter={valueFormatter} />
      <Tooltip formatter={(value) => (valueFormatter ? [valueFormatter(value), ""] : [value, ""])} />
      <Legend />
      {categories.map((category, i) => (
        <Line
          key={category}
          type="monotone"
          dataKey={category}
          stroke={colors[i % colors.length]}
          activeDot={{ r: 8 }}
        />
      ))}
    </RechartsLineChart>
  )
}

interface PieChartProps {
  data: any[]
  index: string
  category: string
  valueFormatter?: (value: number) => string
  className?: string
}

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8", "#9cafff"]

export function PieChart({ data, index, category, valueFormatter, className }: PieChartProps) {
  return (
    <RechartsPieChart className={className}>
      <Pie data={data} dataKey={category} nameKey={index} cx="50%" cy="50%" outerRadius={80} fill="#8884d8" label>
        {data.map((entry, i) => (
          <Cell key={`cell-${i}`} fill={COLORS[i % COLORS.length]} />
        ))}
      </Pie>
      <Tooltip formatter={(value) => (valueFormatter ? [valueFormatter(value), ""] : [value, ""])} />
      <Legend />
    </RechartsPieChart>
  )
}
