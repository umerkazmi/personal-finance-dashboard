"use client"

import { useState } from "react"
import { TransactionForm } from "@/components/transaction-form"
import { SummaryCards } from "@/components/summary-cards"
import { ChartSection } from "@/components/chart-section"
import { FilterSection } from "@/components/filter-section"
import { TransactionList } from "@/components/transaction-list"
import type { Transaction, Category, Currency } from "@/lib/types"
import { initialTransactions, currencies } from "@/lib/data"
import { CurrencySelector } from "@/components/currency-selector"

export function DashboardPage() {
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions)
  const [dateRange, setDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({
    from: undefined,
    to: undefined,
  })
  const [selectedCategories, setSelectedCategories] = useState<Category[]>([])
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>(currencies[0])

  const addTransaction = (transaction: Transaction) => {
    setTransactions([...transactions, transaction])
  }

  const filteredTransactions = transactions.filter((transaction) => {
    // Filter by date range
    if (dateRange.from && new Date(transaction.date) < dateRange.from) return false
    if (dateRange.to && new Date(transaction.date) > dateRange.to) return false

    // Filter by category
    if (selectedCategories.length > 0 && !selectedCategories.includes(transaction.category)) return false

    return true
  })

  const totalIncome = filteredTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

  const totalExpenses = filteredTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

  const currentBalance = totalIncome - totalExpenses

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-4 md:mb-0">
            Personal Finance Dashboard
          </h1>
          <div className="w-full md:w-48">
            <CurrencySelector
              currencies={currencies}
              selectedCurrency={selectedCurrency}
              onCurrencyChange={setSelectedCurrency}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <SummaryCards
              totalIncome={totalIncome}
              totalExpenses={totalExpenses}
              currentBalance={currentBalance}
              currency={selectedCurrency}
            />
          </div>
          <div className="lg:col-span-1">
            <TransactionForm onAddTransaction={addTransaction} currency={selectedCurrency} />
          </div>
        </div>

        <FilterSection
          dateRange={dateRange}
          setDateRange={setDateRange}
          selectedCategories={selectedCategories}
          setSelectedCategories={setSelectedCategories}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <ChartSection transactions={filteredTransactions} currency={selectedCurrency} />
        </div>

        <TransactionList transactions={filteredTransactions} currency={selectedCurrency} />
      </div>
    </div>
  )
}
