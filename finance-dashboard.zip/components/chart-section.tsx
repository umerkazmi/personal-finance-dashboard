"use client"

import { useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Transaction, Currency } from "@/lib/types"
import { BarChart, LineChart, PieChart } from "@/components/ui/chart"
import { groupTransactionsByMonth, groupTransactionsByCategory } from "@/lib/utils"

interface ChartSectionProps {
  transactions: Transaction[]
  currency: Currency
}

export function ChartSection({ transactions, currency }: ChartSectionProps) {
  // Data for line chart (income vs expenses by month)
  const monthlyData = useMemo(() => {
    return groupTransactionsByMonth(transactions)
  }, [transactions])

  // Data for pie chart (expenses by category)
  const categoryData = useMemo(() => {
    return groupTransactionsByCategory(transactions.filter((t) => t.type === "expense"))
  }, [transactions])

  // Data for bar chart (previous months comparison)
  const previousMonthsData = useMemo(() => {
    const last6Months = [...monthlyData].slice(-6)
    return last6Months.map((item) => ({
      name: item.name,
      income: item.income,
      expenses: item.expenses,
    }))
  }, [monthlyData])

  return (
    <>
      <Card className="shadow-md col-span-3 lg:col-span-3">
        <CardHeader>
          <CardTitle>Income vs Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <LineChart
              data={monthlyData}
              categories={["income", "expenses"]}
              index="name"
              colors={["green", "red"]}
              valueFormatter={(value) => `${currency.symbol}${value.toFixed(2)}`}
              className="h-full"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md col-span-3 lg:col-span-1">
        <CardHeader>
          <CardTitle>Spending by Category</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <PieChart
              data={categoryData}
              index="name"
              category="value"
              valueFormatter={(value) => `${currency.symbol}${value.toFixed(2)}`}
              className="h-full"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md col-span-3 lg:col-span-2">
        <CardHeader>
          <CardTitle>Previous Months</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <BarChart
              data={previousMonthsData}
              categories={["income", "expenses"]}
              index="name"
              colors={["green", "red"]}
              valueFormatter={(value) => `${currency.symbol}${value.toFixed(2)}`}
              className="h-full"
            />
          </div>
        </CardContent>
      </Card>
    </>
  )
}
