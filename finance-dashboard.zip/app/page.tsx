import { DashboardPage } from "@/components/dashboard-page"

export default function Home() {
  return <DashboardPage />
}
